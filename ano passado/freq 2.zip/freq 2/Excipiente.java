package teste2;

public class Excipiente {
	
	private String designacao;
	private int percentagem;
	private int pH;
	
	Excipiente(String aDesignacao, int aPercentagem, int aPH) {
		designacao = aDesignacao;
		percentagem = aPercentagem;
		pH = aPH;
	}
	
	public String toString() {
		return "Designacao: " + designacao + " Percentagem: " + percentagem + " pH: " + pH;
	}
}
