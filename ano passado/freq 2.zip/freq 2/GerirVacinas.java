package teste2;

import java.util.Collections;
import java.util.Enumeration;
import java.util.Vector;

public class GerirVacinas {
	
	private Vector <Vacina> vacinas;//ordenar parte 3
	
	GerirVacinas() {
		vacinas = new Vector <Vacina>();
	}
	
	//inserir vacina na lista
	public boolean inserirVacina(Vacina vacina) {
		if(vacinas != null) {
			return vacinas.add(vacina);
		}
		return false;
	}
	
	
	//pesquisar por ano e remover
	public boolean removerVacina(int ano) {
		if(vacinas != null && vacinas.size() > 0) {
			Enumeration <Vacina> elementos = vacinas.elements();
				while(elementos.hasMoreElements() == true) {
					Vacina vacina = elementos.nextElement();
					if(vacina.getAno() == ano) {
						return vacinas.remove(vacina);
					}
				}
			}
		return false;
	}
	
	//pesquisar por designacao
	public Vacina pesquisarDesignacao(String designacao) {
		if(vacinas != null && vacinas.size() > 0) {
			Enumeration <Vacina> elementos = vacinas.elements();
			while(elementos.hasMoreElements() == true) {
				Vacina vacina = elementos.nextElement();
				if(vacina.getDesignacao().equalsIgnoreCase(designacao) == true) {
					return vacina;
				}
			}
		}
		return null;
	}
	
	//pesquisar por codigo de registo
	public Vacina pesquisarCodigo(int codigo) {
		if(vacinas != null && vacinas.size() > 0) {
			Enumeration <Vacina> elementos = vacinas.elements();
			while(elementos.hasMoreElements() == true) {
				Vacina vacina = elementos.nextElement();
				if(vacina.getCodigo() == codigo) {
					return vacina;
				}
			}
		}
		return null;
	}
	
	//listar vacinas e informacao
	public String listarVacinas() {
		if(vacinas != null && vacinas.size() > 0) {
			String listar = "";
			Enumeration <Vacina> elementos = vacinas.elements(); 
				while(elementos.hasMoreElements()) {
					listar += elementos.nextElement() + "\n";
				}
				return listar;
		}
		return null;
	}

	
	//ordenar parte 4
	public void ordenarVacinas() {
		Collections.sort(vacinas);
	}
}
