package teste2;

public class Lab {
	
	private String designacao;
	private int autorizacao;
	
	private Pessoa responsavel;
	
	Lab(String aDesignacao, int aAutorizacao, Pessoa aResponsavel) {
		designacao = aDesignacao;
		autorizacao = aAutorizacao;
		responsavel = aResponsavel;
	}
	
	public void setResponsavel(Pessoa aResponsavel) {
		responsavel = aResponsavel;
	}
	
	public String toString() {
		return "Designacao comercial: " + designacao + " Numero de autorizacao farmaceutica: " + autorizacao + " Responsavel: " + responsavel;
	}
}
