package teste2;

public class Pessoa {
	
	private String nome;
	private int codigo;
	private String categoria;
	private String area;
	
	Pessoa(String aNome, int aCodigo, String aCategoria, String aArea) {
		nome = aNome;
		codigo = aCodigo;
		categoria = aCategoria;
		area = aArea;
	}
	
	public void setCategoria(String aCategoria) {
		categoria = aCategoria;
	}
	
	public int getCodigo() {
		return codigo;
	}
	
	public String toString() {
		return "Nome: " + nome + " Codigo interno: " + codigo + "Categoria profissional: " + categoria + "Area de especializacao: " + area;
	}

}
