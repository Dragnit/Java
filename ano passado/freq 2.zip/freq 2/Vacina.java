package teste2;

import java.util.Enumeration;
import java.util.Vector;


public class Vacina implements Comparable <Vacina>{ //ordernar parte 1
	
	private String designacao;
	private String componente;
	private int ano;
	private int dia;
	private int mes;
	private Lab lab;
	private int codigoEMA;
	private Pessoa lider;
	
	//equipa tecnica
	Vector <Pessoa> equipa = new Vector <Pessoa>(5);
	//conjunto de excipientes
	Vector <Excipiente> excipientes= new Vector <Excipiente>(4);
	
	private static boolean ordenar = false;
	
	Vacina(String aDesignacao, String aComponente, int aDia, int aMes, int aAno, Lab aLab, int aCodigo, Pessoa aLider) {
		designacao = aDesignacao;
		componente = aComponente;
		dia = aDia;
		mes = aMes;
		ano = aAno;
		lab = aLab;
		codigoEMA = aCodigo;
		lider = aLider;
		inserirPessoa(lider); //insere o responsavel na primeira posicao da tabela equipa
	}
	
	public void setCodigoEMA(int codigo) {
		codigoEMA = codigo;
	}
	
	public void setLider(Pessoa aLider) {
		lider = aLider;
		equipa.setElementAt(lider, 0); //modifica o lider na lista
	}
	
	public String getDesignacao() {
		return designacao;
	}
	
	public int getCodigo() {
		return codigoEMA;
	}
	
	public int getAno() {
		return ano;
	}
	
	//inserir pessoa na equipa
	public boolean inserirPessoa(Pessoa p) {
		if(equipa != null && equipa.size() < 5) {
			return equipa.add(p);
		}
		return false;
	}
	
	//inserir excipiente na lista
	public boolean inserirExcipiente(Excipiente e) {
		if(excipientes != null && excipientes.size() < 4) {
			return excipientes.add(e);
		}
		return false;
	}
	
	//listar os excipientes
	public String listarExcipientes() {
		if(excipientes != null && excipientes.size() > 0) {
			String listar = "";
			Enumeration <Excipiente> elementos = excipientes.elements();
			while(elementos.hasMoreElements()) {
				listar += elementos.nextElement() + "\n";
			}
			return listar;
		}
		return null;
	}
	
	//apresentar elementos da equipa tecnica
	public String listarEquipa() {
		if(equipa != null && equipa.size() > 0) {
			String apresentar = "";
			Enumeration <Pessoa> elementos = equipa.elements();
			while(elementos.hasMoreElements()) {
				apresentar += elementos.nextElement() + "\n";
			}
			return apresentar;
		}
		return null;
		
	}
	
	//pesquisar tecnico atraves do codigo interno
	public Pessoa pesquisarTecnico(int codigo) {
		if(equipa != null && equipa.size() > 0) {
			Enumeration <Pessoa> elementos = equipa.elements();
			while(elementos.hasMoreElements() == true) {
				Pessoa pessoa = elementos.nextElement();
				if(pessoa.getCodigo() == codigo) {
					return pessoa;
				}
			}
		}
		return null;
	}

	//ordenar parte 2
	public int compareTo(Vacina vacina) {
		if(ordenar) {
			return designacao.compareTo(vacina.getDesignacao());
		} else {
			if(codigoEMA > vacina.getCodigo())
				return 1;
			if(codigoEMA < vacina.getCodigo())
				return -1;
			return 0;
		}
	}
	
	public String toString() {
		return "Designacao: " + designacao + " Componente activo: " + componente + " Data de fabrico: " 
				+ dia + "-" + mes +  "-" + ano + " Codigo de registo EMA: " + codigoEMA + " Laboratorio de fabricacao: " + lab
				+ "\nExcipientes:\n" + listarExcipientes()
				+ "\nEquipa tecnica:\n" + listarEquipa();
	}

}
